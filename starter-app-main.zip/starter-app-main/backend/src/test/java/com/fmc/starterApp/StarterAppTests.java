package com.fmc.starterApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarterAppTests {

	@Test
	void contextLoads() {
	}

}
