CREATE TABLE if not exists example (
    id BIGINT SERIAL NOT NULl,
    name VARCHAR(255),
    PRIMARY KEY (id)
);

