import { Typography } from "@mui/material";

export const Admin: React.FC = () => {
  return (
    <Typography data-testid="admin-page" sx={{ color: "#FFF" }}>
      This is the admin page. Congratulations!
    </Typography>
  );
};

export default Admin;
